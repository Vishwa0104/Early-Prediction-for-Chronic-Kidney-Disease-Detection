/**
 * Main JavaScript file for CKD Detection System
 * Provides common functionality across all pages
 */

// Global application object
const CKDApp = {
    // Configuration
    config: {
        maxFileSize: 16 * 1024 * 1024, // 16MB
        allowedFileTypes: ['.csv'],
        medicalRanges: {
            age: { min: 18, max: 90, unit: 'years' },
            blood_pressure: { min: 80, max: 250, unit: 'mmHg' },
            specific_gravity: { min: 1.000, max: 1.040, unit: '' },
            albumin: { min: 0, max: 10, unit: 'g/dL' },
            sugar: { min: 0, max: 10, unit: 'g/dL' },
            serum_creatinine: { min: 0.1, max: 20, unit: 'mg/dL' },
            sodium: { min: 100, max: 180, unit: 'mEq/L' },
            potassium: { min: 1.0, max: 8.0, unit: 'mEq/L' },
            calcium: { min: 5.0, max: 15.0, unit: 'mg/dL' },
            hemoglobin: { min: 3.0, max: 20.0, unit: 'g/dL' },
            pcv: { min: 10, max: 60, unit: '%' },
            gfr: { min: 1, max: 200, unit: 'mL/min/1.73m²' },
            wbc_count: { min: 1000, max: 50000, unit: '/µL' },
            rbc_count: { min: 1.0, max: 8.0, unit: 'million/µL' }
        },
        normalRanges: {
            serum_creatinine: { min: 0.6, max: 1.3 },
            gfr: { min: 90, max: 150 },
            hemoglobin: { min: 12.0, max: 16.0 },
            blood_pressure: { min: 90, max: 140 },
            sodium: { min: 135, max: 145 },
            potassium: { min: 3.5, max: 5.0 },
            calcium: { min: 8.5, max: 10.5 },
            pcv: { min: 35, max: 50 },
            wbc_count: { min: 4000, max: 11000 },
            rbc_count: { min: 4.0, max: 6.0 }
        }
    },

    // Initialize the application
    init: function() {
        console.log('CKD Detection System initialized');
        this.setupEventListeners();
        this.initializeTooltips();
        this.setupFormValidation();
        this.setupFileUpload();
        this.initializeChartDefaults();
    },

    // Setup global event listeners
    setupEventListeners: function() {
        // Handle navigation active states
        this.updateNavigation();

        // Handle form submissions with loading states
        document.addEventListener('submit', function(e) {
            const form = e.target;
            if (form.tagName === 'FORM') {
                CKDApp.showFormLoading(form);
            }
        });

        // Handle modal events
        document.addEventListener('shown.bs.modal', function(e) {
            const modal = e.target;
            CKDApp.handleModalShown(modal);
        });

        // Handle print functionality
        document.addEventListener('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
                CKDApp.preparePrintView();
            }
        });
    },

    // Update navigation active states
    updateNavigation: function() {
        const currentPath = window.location.pathname;
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href && currentPath === href) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    },

    // Initialize Bootstrap tooltips
    initializeTooltips: function() {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });

        // Add tooltips for medical terms
        this.addMedicalTooltips();
    },

    // Add tooltips for medical terminology
    addMedicalTooltips: function() {
        const medicalTerms = {
            'GFR': 'Glomerular Filtration Rate - measures kidney function',
            'Creatinine': 'Waste product filtered by kidneys - high levels indicate kidney problems',
            'PCV': 'Packed Cell Volume - percentage of red blood cells in blood',
            'Albumin': 'Protein that should not be present in urine in significant amounts',
            'Specific Gravity': 'Measure of urine concentration',
            'Hemoglobin': 'Protein in red blood cells that carries oxygen'
        };

        Object.keys(medicalTerms).forEach(term => {
            const elements = document.querySelectorAll(`[data-medical-term="${term}"]`);
            elements.forEach(el => {
                el.setAttribute('data-bs-toggle', 'tooltip');
                el.setAttribute('data-bs-placement', 'top');
                el.setAttribute('title', medicalTerms[term]);
                el.classList.add('medical-tooltip');
            });
        });
    },

    // Setup form validation
    setupFormValidation: function() {
        const forms = document.querySelectorAll('.needs-validation, .medical-form');
        
        forms.forEach(form => {
            form.addEventListener('submit', function(e) {
                if (!CKDApp.validateMedicalForm(form)) {
                    e.preventDefault();
                    e.stopPropagation();
                }
                form.classList.add('was-validated');
            });

            // Real-time validation for medical parameters
            const medicalInputs = form.querySelectorAll('input[data-medical-param]');
            medicalInputs.forEach(input => {
                input.addEventListener('blur', function() {
                    CKDApp.validateMedicalParameter(input);
                });
                
                input.addEventListener('input', function() {
                    CKDApp.clearValidationMessage(input);
                });
            });
        });
    },

    // Validate medical form
    validateMedicalForm: function(form) {
        let isValid = true;
        const medicalInputs = form.querySelectorAll('input[data-medical-param]');
        
        medicalInputs.forEach(input => {
            if (!this.validateMedicalParameter(input)) {
                isValid = false;
            }
        });

        return isValid;
    },

    // Validate individual medical parameter
    validateMedicalParameter: function(input) {
        const paramName = input.getAttribute('data-medical-param');
        const value = parseFloat(input.value);
        const ranges = this.config.medicalRanges[paramName];
        const normalRanges = this.config.normalRanges[paramName];

        // Clear previous validation
        this.clearValidationMessage(input);

        if (!input.value.trim()) {
            // Empty values are typically optional
            return true;
        }

        if (isNaN(value)) {
            this.showValidationMessage(input, 'Please enter a valid number', 'error');
            return false;
        }

        if (ranges) {
            if (value < ranges.min || value > ranges.max) {
                this.showValidationMessage(input, 
                    `Value should be between ${ranges.min} and ${ranges.max} ${ranges.unit}`, 
                    'error'
                );
                return false;
            }

            // Check against normal ranges for warnings
            if (normalRanges && (value < normalRanges.min || value > normalRanges.max)) {
                this.showValidationMessage(input, 
                    `Value is outside normal range (${normalRanges.min}-${normalRanges.max} ${ranges.unit})`, 
                    'warning'
                );
                // Still valid, just a warning
                return true;
            }
        }

        this.showValidationMessage(input, 'Valid value', 'success');
        return true;
    },

    // Show validation message
    showValidationMessage: function(input, message, type) {
        const feedbackClass = type === 'error' ? 'invalid-feedback' : 
                             type === 'warning' ? 'warning-feedback' : 'valid-feedback';
        
        let feedback = input.parentNode.querySelector(`.${feedbackClass}`);
        if (!feedback) {
            feedback = document.createElement('div');
            feedback.className = feedbackClass;
            input.parentNode.appendChild(feedback);
        }
        
        feedback.textContent = message;
        feedback.style.display = 'block';

        // Update input styling
        input.classList.remove('is-valid', 'is-invalid', 'is-warning');
        if (type === 'error') {
            input.classList.add('is-invalid');
        } else if (type === 'success') {
            input.classList.add('is-valid');
        } else if (type === 'warning') {
            input.classList.add('is-warning');
        }
    },

    // Clear validation message
    clearValidationMessage: function(input) {
        const feedbacks = input.parentNode.querySelectorAll('.invalid-feedback, .valid-feedback, .warning-feedback');
        feedbacks.forEach(feedback => {
            feedback.style.display = 'none';
        });
        
        input.classList.remove('is-valid', 'is-invalid', 'is-warning');
    },

    // Setup file upload functionality
    setupFileUpload: function() {
        const fileInputs = document.querySelectorAll('input[type="file"]');
        
        fileInputs.forEach(input => {
            input.addEventListener('change', function(e) {
                CKDApp.validateFileUpload(e.target);
            });

            // Setup drag and drop if parent has upload-area class
            const uploadArea = input.closest('.upload-area');
            if (uploadArea) {
                CKDApp.setupDragAndDrop(uploadArea, input);
            }
        });
    },

    // Validate file upload
    validateFileUpload: function(input) {
        const file = input.files[0];
        if (!file) return true;

        // Check file size
        if (file.size > this.config.maxFileSize) {
            this.showAlert(`File size too large. Maximum size is ${this.formatFileSize(this.config.maxFileSize)}.`, 'error');
            input.value = '';
            return false;
        }

        // Check file type
        const fileExtension = '.' + file.name.split('.').pop().toLowerCase();
        if (!this.config.allowedFileTypes.includes(fileExtension)) {
            this.showAlert(`Invalid file type. Please select a CSV file.`, 'error');
            input.value = '';
            return false;
        }

        this.showAlert(`File "${file.name}" selected successfully.`, 'success');
        return true;
    },

    // Setup drag and drop functionality
    setupDragAndDrop: function(uploadArea, fileInput) {
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, function(e) {
                e.preventDefault();
                e.stopPropagation();
            });
        });

        ['dragenter', 'dragover'].forEach(eventName => {
            uploadArea.addEventListener(eventName, function() {
                uploadArea.classList.add('dragover');
            });
        });

        ['dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, function() {
                uploadArea.classList.remove('dragover');
            });
        });

        uploadArea.addEventListener('drop', function(e) {
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                fileInput.files = files;
                CKDApp.validateFileUpload(fileInput);
            }
        });

        // Make upload area clickable
        uploadArea.addEventListener('click', function() {
            fileInput.click();
        });
    },

    // Initialize Chart.js defaults
    initializeChartDefaults: function() {
        if (typeof Chart !== 'undefined') {
            // Set global chart defaults for medical theme
            Chart.defaults.responsive = true;
            Chart.defaults.maintainAspectRatio = false;
            Chart.defaults.plugins.legend.position = 'bottom';
            Chart.defaults.plugins.legend.labels.usePointStyle = true;
            Chart.defaults.plugins.legend.labels.padding = 20;
            
            // Color scheme for medical charts
            Chart.defaults.color = 'rgba(255, 255, 255, 0.8)';
            Chart.defaults.borderColor = 'rgba(255, 255, 255, 0.1)';
        }
    },

    // Medical-specific chart creation helpers
    createRiskChart: function(canvas, data) {
        const ctx = canvas.getContext('2d');
        return new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Low Risk', 'Moderate Risk', 'High Risk'],
                datasets: [{
                    data: data,
                    backgroundColor: [
                        'rgba(40, 167, 69, 0.8)',
                        'rgba(255, 193, 7, 0.8)',
                        'rgba(220, 53, 69, 0.8)'
                    ],
                    borderColor: [
                        'rgba(40, 167, 69, 1)',
                        'rgba(255, 193, 7, 1)',
                        'rgba(220, 53, 69, 1)'
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    },

    // Show form loading state
    showFormLoading: function(form) {
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn) {
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i data-feather="loader" class="me-2"></i>Processing...';
            submitBtn.disabled = true;
            
            // Store original text for restoration
            submitBtn.setAttribute('data-original-text', originalText);
            
            // Replace feather icons
            if (typeof feather !== 'undefined') {
                feather.replace();
            }
        }
    },

    // Handle modal shown events
    handleModalShown: function(modal) {
        // Focus on first input in modal
        const firstInput = modal.querySelector('input, select, textarea');
        if (firstInput) {
            firstInput.focus();
        }
        
        // Initialize any charts in the modal
        const charts = modal.querySelectorAll('canvas');
        charts.forEach(canvas => {
            // Trigger chart resize
            const chartInstance = Chart.getChart(canvas);
            if (chartInstance) {
                chartInstance.resize();
            }
        });
    },

    // Utility functions
    formatMedicalValue: function(value, paramName, decimalPlaces = 2) {
        if (value === null || value === undefined) return 'N/A';
        
        const ranges = this.config.medicalRanges[paramName];
        const unit = ranges ? ranges.unit : '';
        
        try {
            const formattedValue = parseFloat(value).toFixed(decimalPlaces);
            return `${formattedValue} ${unit}`.trim();
        } catch (e) {
            return String(value);
        }
    },

    formatFileSize: function(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    },

    getRiskLevel: function(riskScore) {
        if (riskScore >= 0.7) return { level: 'High', class: 'danger' };
        if (riskScore >= 0.3) return { level: 'Moderate', class: 'warning' };
        return { level: 'Low', class: 'success' };
    },

    getSeverityBadgeClass: function(severity) {
        const classes = {
            'Mild': 'bg-success',
            'Moderate': 'bg-warning',
            'Severe': 'bg-danger'
        };
        return classes[severity] || 'bg-secondary';
    },

    // Show alert message
    showAlert: function(message, type = 'info', duration = 5000) {
        const alertContainer = document.getElementById('alert-container') || this.createAlertContainer();
        
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            <i data-feather="${this.getAlertIcon(type)}" class="me-2"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        alertContainer.appendChild(alertDiv);
        
        // Replace feather icons
        if (typeof feather !== 'undefined') {
            feather.replace();
        }
        
        // Auto-dismiss after duration
        if (duration > 0) {
            setTimeout(() => {
                if (alertDiv.parentNode) {
                    const alert = new bootstrap.Alert(alertDiv);
                    alert.close();
                }
            }, duration);
        }
    },

    createAlertContainer: function() {
        const container = document.createElement('div');
        container.id = 'alert-container';
        container.className = 'position-fixed top-0 end-0 p-3';
        container.style.zIndex = '9999';
        document.body.appendChild(container);
        return container;
    },

    getAlertIcon: function(type) {
        const icons = {
            'success': 'check-circle',
            'error': 'alert-triangle',
            'warning': 'alert-circle',
            'info': 'info'
        };
        return icons[type] || 'info';
    },

    // Prepare view for printing
    preparePrintView: function() {
        // Add print-specific classes
        document.body.classList.add('printing');
        
        // Hide non-essential elements
        const hideElements = document.querySelectorAll('.no-print, .navbar, .btn, .modal');
        hideElements.forEach(el => el.style.display = 'none');
        
        // Restore after print
        window.addEventListener('afterprint', function() {
            document.body.classList.remove('printing');
            hideElements.forEach(el => el.style.display = '');
        });
    },

    // Export functions for global use
    utils: {
        formatMedicalValue: function(value, paramName, decimalPlaces = 2) {
            return CKDApp.formatMedicalValue(value, paramName, decimalPlaces);
        },
        
        getRiskLevel: function(riskScore) {
            return CKDApp.getRiskLevel(riskScore);
        },
        
        showAlert: function(message, type, duration) {
            return CKDApp.showAlert(message, type, duration);
        }
    }
};

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    CKDApp.init();
});

// Make CKDApp globally available
window.CKDApp = CKDApp;

// Custom CSS for warning feedback (since Bootstrap doesn't have this)
const style = document.createElement('style');
style.textContent = `
    .warning-feedback {
        display: none;
        width: 100%;
        margin-top: 0.25rem;
        font-size: 0.875em;
        color: #f57c00;
    }
    
    .is-warning {
        border-color: #f57c00;
    }
    
    .is-warning:focus {
        border-color: #f57c00;
        box-shadow: 0 0 0 0.2rem rgba(245, 124, 0, 0.25);
    }
`;
document.head.appendChild(style);
